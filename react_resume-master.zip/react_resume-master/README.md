# React_Resume

To build a Resume builder using react and node.js